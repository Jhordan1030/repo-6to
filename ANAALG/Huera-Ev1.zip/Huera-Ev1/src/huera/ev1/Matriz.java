package huera.ev1;
public class Matriz {
    private int[][] matrizDatos;
    private int numeroDeFilas;
    private int numeroDeColumnas;

    public Matriz(int filas, int columnas) {
        this.numeroDeFilas = filas;
        this.numeroDeColumnas = columnas;
        this.matrizDatos = new int[filas][columnas];
    }

    public void llenarMatriz() {
        this.matrizDatos = GenerarMatriz.generarMatriz(numeroDeFilas, numeroDeColumnas);
    }

    public void imprimirMatriz() {
        for (int fila = 0; fila < numeroDeFilas; fila++) {
            for (int columna = 0; columna < numeroDeColumnas; columna++) {
                System.out.print(matrizDatos[fila][columna] + "\t");
            }
            System.out.println();
        }
    }

    public int[] obtenerFila(int indiceFila) {
        return matrizDatos[indiceFila];
    }

    public void actualizarFila(int indiceFila, int[] filaOrdenada) {
        matrizDatos[indiceFila] = filaOrdenada;
    }
}
