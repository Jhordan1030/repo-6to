package huera.ev1;

public class GenerarMatriz {

    public static int[][] generarMatriz(int filas, int columnas) {
    int[][] matrizGenerada = new int[filas][columnas];
    int numero = 1;
    int limite = filas * columnas; 

    int inicioFila = 0, finFila = filas - 1;
    int inicioColumna = columnas - 1, finColumna = 0;

    while (inicioFila <= finFila && inicioColumna >= finColumna) {

        for (int fila = inicioFila; fila <= finFila; fila++) {
            if (numero <= limite) {
                matrizGenerada[fila][inicioColumna] = numero++;
            }
        }
        inicioColumna--;

        if (inicioColumna >= finColumna) {
            for (int columna = inicioColumna; columna >= finColumna; columna--) {
                if (numero <= limite) {
                    matrizGenerada[finFila][columna] = numero++;
                }
            }
            finFila--;
        }

        if (inicioFila <= finFila) {
            for (int fila = finFila; fila >= inicioFila; fila--) {
                if (numero <= limite) {
                    matrizGenerada[fila][finColumna] = numero++;
                }
            }
            finColumna++;
        }
        
        if (inicioColumna >= finColumna) {
            for (int columna = finColumna; columna <= inicioColumna; columna++) {
                if (numero <= limite) {
                    matrizGenerada[inicioFila][columna] = numero++;
                }
            }
            inicioFila++;
        }
    }

    return matrizGenerada;
}


}
