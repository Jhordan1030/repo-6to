package huera.ev1;

import java.util.Scanner;

public class HueraEv1 {
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        System.out.println("Grupo 3");
        System.out.print("Ingrese el número de filas: ");
        int filas = scanner.nextInt();

        System.out.print("Ingrese el número de columnas: ");
        int columnas = scanner.nextInt();
        
        Matriz matriz = new Matriz(filas, columnas);
        matriz.llenarMatriz();
        
        System.out.println("\nMatriz Generada:");
        matriz.imprimirMatriz();
        
        System.out.print("Ingrese el número de fila a ordenar (0 a " + (filas - 1) + "): ");
        int filaSeleccionada = scanner.nextInt();
        
        int[] fila = matriz.obtenerFila(filaSeleccionada);
        
        OrdenarShell.ordenarFila(fila);
        
        matriz.actualizarFila(filaSeleccionada, fila);

        System.out.println("\nMatriz con fila ordenada: " + filaSeleccionada);
        matriz.imprimirMatriz();
    }
    
}
