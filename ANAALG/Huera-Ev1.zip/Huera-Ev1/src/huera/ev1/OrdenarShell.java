package huera.ev1;
public class OrdenarShell {
    
    public static void ordenarFila(int[] fila) {
        int longitud = fila.length;
        
        for (int intervalo = longitud / 2; intervalo > 0; intervalo /= 2) {
            for (int indice = intervalo; indice < longitud; indice++) {
                int valorTemporal = fila[indice];
                int posicion = indice;

                while (posicion >= intervalo && fila[posicion - intervalo] > valorTemporal) {
                    fila[posicion] = fila[posicion - intervalo];
                    posicion -= intervalo;
                }
                fila[posicion] = valorTemporal;
            }
        }
    }
}
